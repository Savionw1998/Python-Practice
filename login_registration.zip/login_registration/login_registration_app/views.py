from django.shortcuts import render, redirect
from .models import User 
from django.contrib import messages
import bcrypt

# Create your views here.
def Index(request):
    return render(request, 'Home.html')


def Login(request):
    errors = User.objects.login_validator(request.POST)
    if errors:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    user = User.objects.filter(email=request.POST['email'])
    if user:
        logged_user = user[0] 
        if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
            request.session['userid'] = logged_user.id
            return render(request,'success.html')
        else:
            print('$$$$$$$$')
            messages.add_message(request, messages.INFO, "Incorrect password or no account exists")
            return redirect('/')

def logout():
    del request.session['userid']
    return redirect('/')


def Register(request):
    errors = User.objects.basic_validator(request.POST)
    password = request.POST['password']
    pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        new_user = User.objects.create(
            First_Name = request.POST['first_name'],
            Last_Name = request.POST['last_name'],
            Email = request.POST['email'],
            Password = pw_hash,
            Confirm_Password = pw_hash,
        )
        request.session["user_id"] = new_user.id
        return redirect('/')