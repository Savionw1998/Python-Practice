from django.apps import AppConfig


class RestfullAppConfig(AppConfig):
    name = 'restfull_app'
