from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Show

def Home(request):
    all_shows = Show.objects.all()
    context = {
        "TheShows": all_shows,
    }
    return render(request, 'all_shows.html', context)

def GetShow(request, show_id):
    shows = Show.objects.get(id=show_id)
    context = {
        "TheShows": shows,
    }
    return render(request, 'getshow.html', context)

def RenderNewShow(request):
    return render(request, 'add_new_show.html')

def Edit(request, show_id):
    context= {
        "This_Show": Show.objects.get(id=show_id)
    }
    return render(request, 'edit_show.html', context)

def Update(request, show_id):
    errors = Show.objects.basic_validator(request.POST)
        # check if the errors dictionary has anything in it
    if len(errors) > 0:
        # if the errors dictionary contains anything, loop through each key-value pair and make a flash message
        for key, value in errors.items():
            messages.error(request, value)
        # redirect the user back to the form to fix the errors
        return redirect(f'/shows/{show_id}/edit')
    else:
        This_Show= Show.objects.get(id=show_id)
        This_Show.Title = request.POST['title']
        This_Show.Network = request.POST['show_network']
        This_Show.Release_Date = request.POST['release_date']
        This_Show.Description = request.POST['description']
        This_Show.save()
        messages.success(request, "Show successfully updated")
        return redirect(f'/shows/{show_id}')

def Kill(request, show_id):
    Delete_Show = Show.objects.get(id=show_id)
    Delete_Show.delete()
    return redirect('/shows')

def AddNew(request):
    if request.method == "POST":
        errors = Show.objects.basic_validator(request.POST)
        # check if the errors dictionary has anything in it
    if len(errors) > 0:
        # if the errors dictionary contains anything, loop through each key-value pair and make a flash message
        for key, value in errors.items():
            messages.error(request, value)
        # redirect the user back to the form to fix the errors
        return redirect(f'/shows/new')
    else:
        new_show = Show.objects.create(
            Title = request.POST['title'],
            Network = request.POST['show_network'],
            Release_Date = request.POST['release_date'],
            Description = request.POST['description']
        )
    new_show_id = new_show.id
    return redirect(f'/shows/{new_show_id}')
