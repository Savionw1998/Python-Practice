from django.urls import path
from . import views

urlpatterns = [
    path('shows', views.Home),
    path('shows/<int:show_id>', views.GetShow),
    path('shows/new', views.RenderNewShow),
    path('shows/<int:show_id>/edit', views.Edit),
    path('shows/create_new', views.AddNew),
    path('shows/update/<int:show_id>', views.Update),
    path('shows/<int:show_id>/destroy', views.Kill),
]