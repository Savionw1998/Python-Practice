from django.shortcuts import render, redirect
def index(request):
    return render(request, "index.html")
def create_user(request):
    # this is the route that processes the form
    print("..................")
    first_name = request.POST['first_name']
    last_name = request.POST['last_name']
    email = request.POST['email']
    context = {
        "first name" : first_name,
        "last name" : last_name,
        "email" : email,
    }
    return render(request,"give.html", context)