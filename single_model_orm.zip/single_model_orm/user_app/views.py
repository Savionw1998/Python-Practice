from django.shortcuts import render
from .models import User


def index(request):
    context = {
        "all_users" : User.objects.all()
    }
    return render(request, 'index.html', context)

def create_user(request):
    # this is the route that processes the form
    first_name = request.POST['first_name']
    last_name = request.POST['last_name']
    email = request.POST['email']
    context = {
        "first name" : first_name,
        "last name" : last_name,
        "email" : email,
    }
    return render(request, 'user_page.html', context)
