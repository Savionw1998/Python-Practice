from django.urls import path
from . import views

urlpatterns = [
    path('', views.Home),
    path('bookpage', views.Login),
    path('bookpage/register', views.Register),
    path('bookpage/add_book', views.AddBook),
    path('bookpage/<int:Book_id>', views.BookInfo),
]