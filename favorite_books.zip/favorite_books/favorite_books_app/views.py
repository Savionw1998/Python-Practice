from django.shortcuts import render, redirect
from .models import User, Book
import bcrypt
from django.contrib import messages


# Create your views here.
def Home(request):
    return render(request, 'Home.html')

def Register(request):
    errors = User.objects.basic_validator(request.POST)
    password = request.POST['password']
    pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        new_user = User.objects.create(
            first_name = request.POST['first_name'],
            last_name = request.POST['last_name'],
            email = request.POST['email'],
            password = pw_hash,
            confirm_password = pw_hash,
        )
        request.session["user_id"] = new_user.id
        return redirect('/')

def AddBook(request):
    new_book = Book.objects.create(
        title = request.POST['title'],
        description = request.POST['description'],
        users_favorite = User1
    )
    return redirect('/bookpage')



def Login(request):
    # print(request.POST)
    # errors = User.objects.login_validator(request.POST)
    # if errors:
    #     for key, value in errors.items():
    #         messages.error(request, messages)
    #     return redirect('/')
    # allbooks = Book.objects.all()
    user = User.objects.filter(email=request.POST['email'])
    if user:
        logged_user = user[0] 
        if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
            request.session['userid'] = logged_user.id
            user1 = User.objects.get(id=logged_user.id)
            books = Book.objects.all()
            context = {
                'User1' : user1,
                'Book' : books,
            }
            return render(request,'Books.html', context)
        else:
    # messages.add_message(request, messages.INFO, "Incorrect password or no account exists")
            return redirect('/')

def BookInfo(request, Book_id):
    book = Book.objects.get(id=Book_id)
    context = {
        "TheBook" : book,
    }
    return render(request, 'BookInfo.html', context)