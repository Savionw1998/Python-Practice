from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('ninja_info', views.AddNewNinja),
    path('dojo_info', views.AddNewDojo)


]