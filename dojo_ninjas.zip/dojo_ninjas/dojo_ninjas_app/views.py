from django.shortcuts import render, redirect
from .models import Ninja, Dojo

# Create your views here.
def index(request):
    all_dojos = Dojo.objects.all()
    all_ninjas = Ninja.objects.all()
    context = {
        'AllNinjas' : all_ninjas,
        'AllDojos' : all_dojos
    }
    return render(request, 'index.html', context)

# def create_dojo(request):
#     # this is the route that processes the form
#     Dojo.objects.create(
#     name = request.POST['name'],
#     city = request.POST['city'],
#     state = request.POST['state']
#     )
#     return redirect('')

# def create_ninja(request):
#     # this is the route that processes the form
#     Ninja.objects.create(
#     first_name = request.POST['first_name'],
#     last_name = request.POST['last_name'],
#     Dojo = request.POST['dojo']
#     )
#     return redirect('')

def AddNewNinja(request):
    Dojos = Dojo.objects.all()
    if request.method == "POST":
        Ninja.objects.create(
            First_Name = request.POST['first_name'],
            Last_Name = request.POST['last_name'],
            dojo_id = request.POST[Dojos.id]
        )
    return redirect('/')

def AddNewDojo(request):
    if request.method == "POST":
        Dojo.objects.create(
            Name = request.POST['name'],
            City = request.POST['city'],
            State = request.POST['state'],
        )
    return redirect('/')
